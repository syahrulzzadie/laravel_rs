<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Dokter</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/sweetalert2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/fontawesome.min.css')); ?>">
    <script src="<?php echo e(url('assets/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/sweetalert2.min.js')); ?>"></script>
</head>
<body>
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-lg-12">
                <div class="form-group">
                    <button type="button" onclick="modal_tambah()"  class="btn btn-primary">Tambah Data</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-consended table-bordered">
                        <thead class="bg-primary text-white">
                            <tr>
                                <th>KODE</th>
                                <th>NAMA</th>
                                <th>JENIS KELAMIN</th>
                                <th>ALAMAT</th>
                                <th>FOTO</th>
                                <th>AKSI</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data_dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->kode); ?></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->jenis_kelamin); ?></td>
                                <td><?php echo e($row->alamat); ?></td>
                                <td>
                                    <img src="<?php echo e($row->foto); ?>" class="img-fluid">
                                </td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="modal_edit('<?php echo e($row->id); ?>')">Edit</button>
                                    <button type="button" class="btn btn-danger btn-sm" onclick="modal_delete('<?php echo e($row->id); ?>')">Hapus</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" id="modal-tambah" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Tambah Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <form method="post" action="<?php echo e(url('insert')); ?>">
          <div class="modal-body">
            <div class="form-group">
                <label>Kode</label>
                <input type="text" name="kode" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" class="form-control" required>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Foto</label>
                <input type="file" name="foto" class="form-control" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary">Simpan</button>
            <button type="submit" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          </div>
      </form>
    </div>
</div>
</div>
<div class="modal" id="modal-edit" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <form method="post" action="<?php echo e(url('update')); ?>">
        <input type="hidden" name="id" id="id">
          <div class="modal-body">
            <div class="form-group">
                <label>Kode</label>
                <input type="text" name="kode" id="kode" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" id="nama" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control" required>
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <input type="text" name="alamat" id="alamat" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Foto</label>
                <input type="file" name="foto" class="form-control" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary">Update</button>
            <button type="submit" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          </div>
      </form>
    </div>
</div>
</div>
<div class="modal" id="modal-delete" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Delete Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <form method="post" action="<?php echo e(url('delete')); ?>">
        <input type="hidden" name="id" id="id2">
          <div class="modal-body">
            <h1>Apakah anda yakin?</h1>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary">Update</button>
            <button type="submit" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          </div>
      </form>
    </div>
</div>
</div>
<script type="text/javascript">
function modal_tambah() {
    $('#modal-tambah').modal('show');
}
function modal_edit(id) {
    $.post('<?php echo e(url("get")); ?>',{id:id},(res)=>{
        if (res.status === "true") {
            $('#id').val(res.data.id);
            $('#kode').val(res.data.kode);
            $('#nama').val(res.data.nama);
            $('#jenis_kelamin').val(res.data.jenis_kelamin);
            $('#alamat').val(res.data.alamat);
            $('#foto').val(res.data.foto);
            $('#modal-edit').modal('show');
        }
    });
}
function modal_delete(id) {
    $('#id2').val(id);
    $('#modal-delete').modal('show');
}
</script>
</body>
</html><?php /**PATH C:\ProjectLaravel\rsi\resources\views/dokter.blade.php ENDPATH**/ ?>