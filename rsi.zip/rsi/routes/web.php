<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\CrudController;

Route::any('/',[CrudController::class,'index']);
Route::any('/get',[CrudController::class,'getData']);
Route::any('/insert',[CrudController::class,'insertData']);
Route::any('/update',[CrudController::class,'updateData']);
Route::any('/delete',[CrudController::class,'deleteData']);
