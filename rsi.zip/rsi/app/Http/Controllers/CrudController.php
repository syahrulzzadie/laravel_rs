<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Dokter as dokter;

class CrudController extends Controller
{
    public static function index()
    {
        $data['data_dokter'] = dokter::showData();
        return view('dokter',$data);
    }
    public static function getData(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kode' => 'required',
        ]);
        if (!$validator->fails()) {
            $where['kode'] = $request->input('kode');
            if (dokter::cekData($where)) {
                $data = dokter::getData($where);
                return response()->json(['status'=>'true','data'=>$data,'message'=>'OK!']);
            } else {
                return response()->json(['status'=>'false','message'=>'Data tidak ditemukan!']);
            }
        } else {
            return response()->json(['status'=>'false','message'=>'Semua form harus diisi!']);
        }
    }
    public static function insertData(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kode' => 'required',
            'nama' => 'required',
            'jenis_kelamin' => 'required',
            'alamat' => 'required',
            'foto' => 'required',
        ]);
        if (!$validator->fails()) {
            $filename = md5(date("YmdHis")).".jpg";
            $path = $request->file('foto')->move(public_path()."uploads/".$filename);
            if (file_exists($path)) {
                $value['kode'] = $request->input('kode');
                $value['nama'] = $request->input('nama');
                $value['jenis_kelamin'] = $request->input('jenis_kelamin');
                $value['alamat'] = $request->input('alamat');
                $value['foto'] = $filename;
                $where['kode'] = $request->input('kode');
                if (dokter::cekData($where)) {
                    if (dokter::insertData($value)) {
                        return response()->json(['status'=>'true','message'=>'Berhasil disimpan!']);
                    } else {
                        return response()->json(['status'=>'false','message'=>'Gagal disimpan!']);
                    }
                } else {
                    return response()->json(['status'=>'false','message'=>'Kode dokter sudah ada!']);
                }
            } else {
                return response()->json(['status'=>'false','message'=>'Gagal upload foto!']);
            }
        } else {
            return response()->json(['status'=>'false','message'=>'Semua form harus diisi!']);
        }
    }
    public static function updateData(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kode' => 'required',
            'nama' => 'required',
            'jenis_kelamin' => 'required',
            'alamat' => 'required',
            'foto' => 'required',
        ]);
        if (!$validator->fails()) {
            $filename = md5(date("YmdHis")).".jpg";
            $path = $request->file('foto')->move(public_path()."uploads/".$filename);
            if (file_exists($path)) {
                $value['kode'] = $request->input('kode');
                $value['nama'] = $request->input('nama');
                $value['jenis_kelamin'] = $request->input('jenis_kelamin');
                $value['alamat'] = $request->input('alamat');
                $value['foto'] = $filename;
                $where['kode'] = $request->input('kode');
                if (dokter::updateData($value,$where)) {
                    return response()->json(['status'=>'true','message'=>'Berhasil disimpan!']);
                } else {
                    return response()->json(['status'=>'false','message'=>'Gagal disimpan!']);
                }
            } else {
                return response()->json(['status'=>'false','message'=>'Gagal upload foto!']);
            }
        } else {
            return response()->json(['status'=>'false','message'=>'Semua form harus diisi!']);
        }
    }
    public static function deleteData(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'kode' => 'required',
        ]);
        if (!$validator->fails()) {
            $where['kode'] = $request->input('kode');
            if (dokter::deleteData($value,$where)) {
                return response()->json(['status'=>'true','message'=>'Berhasil dihapus!']);
            } else {
                return response()->json(['status'=>'false','message'=>'Gagal dihapus!']);
            }
        } else {
            return response()->json(['status'=>'false','message'=>'Semua form harus diisi!']);
        }
    }
}
