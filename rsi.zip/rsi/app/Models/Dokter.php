<?php
namespace App\Models;

use Illuminate\Support\Facades\DB;

class Dokter
{
    public static function showData()
    {
        return DB::table('data_dokter')->get();
    }
    public static function cekData($where)
    {
        $rows = DB::table('data_dokter')->where($where)->count();
        if ($rows > 0) {
            return true;
        }
        return false;
    }
    public static function getData($where)
    {
        return DB::table('data_dokter')->where($where)->first();
    }
    public static function insertData($value)
    {
        if (DB::table('data_dokter')->insert($value)) {
            return true;
        }
        return false;
    }
    public static function updateData($value,$where)
    {
        if (DB::table('data_dokter')->where($where)->update($value)) {
            return true;
        }
        return false;
    }
    public static function deleteData($where)
    {
        if (DB::table($table)->where($where)->delete()) {
            return true;
        }
        return false;
    }
}
